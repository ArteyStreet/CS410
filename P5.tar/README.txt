To make project run the command: ~$ make all

To run the project run: ~$ ./raytracer drivers/driver_name.txt image_name.ppm

To clean the project run: ~$ make clean

I was unable to implement a new feature for P5. I attempted to implement texture mapping, but got lost trying to read
the texture image and finishing model refraction from P4. I now have model refraction.

Scene 1 is driver00.txt - 00.ppm

Scene 2 is driver01.txt - 01.ppm